
let img1; 
let img2; 

function preload() {
  img1 = loadImage("santa.png");
  img2 = loadImage("tree.png");
}

function setup() {
  createCanvas(400, 400); 
  textFont("Arial"); 
}

function draw() {
  background(255, 255, 255); 

  let x = mouseX;
  let y = 200;
  image(img1, x, y, 100, 100);


  push();
  translate(345, 245);

  let s = map(mouseX, 0, height, 0.5, 1.5);
  scale(s);
  image(img2, -100,-100, 200, 200);
  pop();


  fill(20, 100, 20);
  stroke(100,0,0);    
  strokeWeight(1);

  textSize(30);


  text(
    "Happy Holidays!\nHave a wonderful Christmas and New Years!",
    60, 25,   // x, y
    300, 150  // width, height (limits text area)
  );
}