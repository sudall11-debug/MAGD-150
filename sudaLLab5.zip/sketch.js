let x = 200
let y = 200
let speedX = 3
let speedY = 2
let ballColor

function setup() {
  createCanvas(400,400)
  ballColor = color(190,150,255)
}
function draw() {
  background(100)
  
  x = x + speedX
  y = y + speedY
  if (x > width - 45 || x < 45)
    speedX = speedX * -1
  if (y > height - 45 || y < 45) {
    speedY = speedY * -1
  }
  
  fill(ballColor)
  ellipse(x,y,100,100)
  fill(100,200,100)
  for (let i = 0; i < width; i += 110) {
    ellipse(i + 40,380, 100,100)
  }
  
  if (mouseX > width/2) {
    fill(255,50,30)
    rect(50,20,60,30)
  }
  
  else if (mouseX <= width/2) {
    fill(30,50,150)
    rect(300,20,60,30)
  }
}
function mousePressed() {
  ballColor = color(random(255),random(255),random(255))
}
function keyPressed() {
  if (key == 'r' || key == 'R') 
    x = 200
    y = 200
}