let a1 = [];
let a2 = [];
let a3 = [];

function setup() {
  createCanvas(400, 400);
  textSize(14);

  build();
  mix();
  showConsole();
}


function build() {
  for (let i = 1; i <= 5; i++) {
    a2.push(i * 10);
    a1.push(i);
  }
  a1.unshift(-1);
  a2.splice(1, 0, 99);

  a1.push(500);
  a2.push(800);

  let removed1 = a1.pop();
  let removed2 = a2.pop();

  console.log("Popped from a1:", removed1);
  console.log("Popped from a2:", removed2);
}


function mix() {
  a3 = a2.concat(a1);
}

// console output
function showConsole() {
  console.log("Array 1:", a1.toString());
  console.log("Array 2:", a2.toString());
  console.log("Combined Array:", a3.toString());
}

function draw() {
  background(220);
  fill(0);


  let r3 = random(a3);
  let r1 = random(a1);
  let r2 = random(a2);

  text("Array 1: " + a1, 10, 50);
  text("Array 2: " + a2, 10, 100);

  text("Random 1: " + r1, 10, 170);
  text("Random 2: " + r2, 10, 210);
  text("Random 1 & 2: " + r3, 10, 250);
}