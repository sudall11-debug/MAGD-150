function setup() {
  createCanvas(400, 400);
  noLoop();
}

function draw() {
  background(220);

  let skyGrad = drawingContext.createLinearGradient(0, 0, 0, height);
  skyGrad.addColorStop(0, '#1e3c72');  // dark blue
  skyGrad.addColorStop(1, '#87ceeb');  // light blue
  drawingContext.fillStyle = skyGrad;
  rect(0, 0, width, height);
  
  let buildingGrad = drawingContext.createLinearGradient(0, 150, 0, height);
  buildingGrad.addColorStop(0, '#444');   // top darker
  buildingGrad.addColorStop(1, '#999');   // bottom lighter
  drawingContext.fillStyle = buildingGrad;
  rect(150, 150, 100, 250);

  fill(255, 220);
  for (let y = 170; y < 380; y += 25) {
    for (let x = 165; x < 235; x += 20) {
      rect(x, y, 10, 15);
    }
  }
  
noStroke()
  let sunGrad = drawingContext.createRadialGradient(
    320, 80, 10,
    320, 80, 60
  );
  sunGrad.addColorStop(0, '#fffacd'); // light yellow
  sunGrad.addColorStop(1, 'rgba(255,255,200,0)');
  drawingContext.fillStyle = sunGrad;
  ellipse(320, 80, 120, 120);
}